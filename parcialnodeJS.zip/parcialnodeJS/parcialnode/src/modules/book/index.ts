import { Request, Response, Router } from 'express';
import { crearLibro, eliminarLibro, obtenerTodosLibros, obtenerLibroPorId, actualizarLibro } from './controller/book.controller';
import { validadorEsquema } from '../../middleware/schema.middleware';
import { esquemaLibroCreacion } from './schemas/book.schema';

const routerLibro = Router();

routerLibro.get('/:id', async (req: Request, res: Response) => {
    const id = req.params.id;
    const libro = await obtenerLibroPorId(id);
    if (!libro) {
        res.status(404).send({
            mensaje: 'Libro no encontrado'
        });
    } else {
        res.status(200).send(libro);
    }
});

routerLibro.post('/', validadorEsquema(esquemaLibroCreacion), async (req: Request, res: Response) => {
    try {
        console.log('Entrando en la ruta');
        const cuerpo = req.body; // Payload -> Carga útil de la petición
        const nuevoLibro = await crearLibro(cuerpo);
        res.status(201).send({ mensaje: 'Creado con éxito', libro: nuevoLibro });
    } catch (error) {
        res.status(400).send({
            mensaje: 'Error al crear el libro'
        });
    }
});

routerLibro.get('/', async (req: Request, res: Response) => {
    try {
        const libros = await obtenerTodosLibros();
        res.status(200).send({
            libros: libros
        });
    } catch (error) {
        res.status(500).send({
            mensaje: 'Error al obtener los libros'
        });
    }
});

routerLibro.patch('/:id', validadorEsquema(esquemaLibroCreacion), async (req: Request, res: Response) => {
    try {
        const id = req.params.id;
        const libro = await obtenerLibroPorId(id);
        if (!libro) {
            res.status(404).send({
                mensaje: 'Libro no encontrado'
            });
        } else {
            const cuerpo = req.body;
            await actualizarLibro(id, cuerpo);
            const libroActualizado = await obtenerLibroPorId(id);
            res.status(200).send({ mensaje: 'Actualizado con éxito', libro: libroActualizado });
        }
    } catch (error) {
        res.status(500).send({
            mensaje: 'Error al actualizar el libro'
        });
    }
});

routerLibro.delete('/:id', async (req: Request, res: Response) => {
    try {
        const id = req.params.id;
        const libro = await obtenerLibroPorId(id);
        if (!libro) {
            res.status(404).send({
                mensaje: 'Libro no encontrado'
            });
        } else {
            await eliminarLibro(id);
            res.status(200).send({ mensaje: 'Eliminado con éxito' });
        }
    } catch (error) {
        res.status(500).send({
            mensaje: 'Error al eliminar el libro'
        });
    }
});

export { routerLibro };
