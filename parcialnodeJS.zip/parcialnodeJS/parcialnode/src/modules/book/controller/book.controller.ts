import { Types } from 'mongoose';
import { IBook } from '../interface/book.interface';
import { BookModel } from '../models/book.model'; // Asegúrate de que el modelo se llame 'book.model'

/**
 * Crea un nuevo libro en la base de datos.
 * @param {IBook} libro - El libro a crear.
 * @returns {Promise<IBook>} - El libro creado.
 */
export const crearLibro = async (libro: IBook) => {
    try {
        // Creación en memoria y guardado en la base de datos
        const nuevoLibro = new BookModel(libro);
        return await nuevoLibro.save();
    } catch (error) {
        throw new Error("No se pudo guardar el libro en la base de datos.");
    }
};

/**
 * Obtiene todos los libros de la base de datos.
 * @returns {Promise<IBook[]>} - Lista de todos los libros.
 */
export const obtenerTodosLosLibros = async () => {
    try {
        return await BookModel.find();
    } catch (error) {
        throw new Error("No se pudo obtener los libros almacenados.");
    }
};

/**
 * Obtiene un libro por su ID.
 * @param {string} id - El ID del libro.
 * @returns {Promise<IBook | null>} - El libro encontrado o null si no se encuentra.
 */
export const obtenerLibroPorId = async (id: string) => {
    try {
        return await BookModel.findById(id);
    } catch (error) {
        throw new Error("No se pudo encontrar el libro.");
    }
};

/**
 * Elimina un libro por su ID.
 * @param {string} id - El ID del libro a eliminar.
 * @returns {Promise<IBook | null>} - El libro eliminado o null si no se encontraba.
 */
export const eliminarLibro = async (id: string) => {
    try {
        return await BookModel.findByIdAndDelete(id);
    } catch (error) {
        throw new Error("No se pudo eliminar el libro.");
    }
};

/**
 * Actualiza un libro por su ID.
 * @param {string} id - El ID del libro a actualizar.
 * @param {Partial<IBook>} datosActualizados - Los datos a actualizar.
 * @returns {Promise<IBook | null>} - El libro actualizado o null si no se encontraba.
 */
export const actualizarLibro = async (id: string, datosActualizados: Partial<IBook>) => {
    try {
        return await BookModel.findByIdAndUpdate(id, datosActualizados, { new: true });
    } catch (error) {
        throw new Error("No se pudo actualizar el libro.");
    }
};
