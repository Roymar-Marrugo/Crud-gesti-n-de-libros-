import mongoose from 'mongoose';

/**
 * Establece la conexión con la base de datos.
 * @param {string} uri - La URI de conexión a la base de datos.
 */
const conectarBD = async (uri: string) => {
    try {
        await mongoose.connect(uri);
        console.log("Conexión a la base de datos establecida con éxito.");
    } catch (error) {
        console.error("Error al intentar conectar con la base de datos:", error);
    }
};

export { conectarBD };
