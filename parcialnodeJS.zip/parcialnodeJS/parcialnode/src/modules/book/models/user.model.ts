import { Schema, model } from 'mongoose';
import { Libro } from '../interface/book.interface'; // Actualiza la importación según el nuevo nombre de la interfaz

// Definición del esquema para los libros
const EsquemaLibro = new Schema<Libro>({
    titulo: { type: String, required: true },
    autor: { type: String, required: true },
    fechaPublicacion: { type: Date, required: true },
    isbn: { type: String, required: true },
    genero: { type: String, required: true }
});

// Creación del modelo para los libros
export const ModeloLibro = model<Libro>('Libro', EsquemaLibro);
