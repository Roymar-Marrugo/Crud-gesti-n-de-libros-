import { NextFunction, Request, Response } from 'express';
import Joi from 'joi';

/**
 * Middleware para validar el cuerpo de las solicitudes con un esquema de Joi.
 * @param {Joi.Schema} esquema - El esquema de validación de Joi.
 * @returns {(req: Request, res: Response, next: NextFunction) => void} - El middleware de validación.
 */
export const validarEsquema = (esquema: Joi.Schema) => {
    return (req: Request, res: Response, next: NextFunction) => {
        const datos = req.body;
        const { error } = esquema.validate(datos);

        if (error) {
            res.status(400).json({
                mensaje: "Todos los campos del cuerpo de la solicitud deben estar presentes y ser válidos."
            });
        } else {
            next();
        }
    };
};
