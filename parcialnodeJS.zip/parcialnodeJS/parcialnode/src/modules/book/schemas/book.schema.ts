import Joi from 'joi';

// Definir los atributos básicos
const titulo = Joi.string();
const autor = Joi.string();
const fechaPublicacion = Joi.date();
const isbn = Joi.string();
const genero = Joi.string();

// Esquema para la creación de libros
export const esquemaLibroCreacion = Joi.object({
    titulo: titulo.required(),
    autor: autor.required(),
    fechaPublicacion: fechaPublicacion.required(),
    isbn: isbn.required(),
    genero: genero.required()
});
