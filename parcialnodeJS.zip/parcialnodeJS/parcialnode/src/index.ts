import express, { Request, Response } from 'express';
import { inicializarBaseDatos } from './database/db'; // Función para conectar con la base de datos
import { Configuracion } from './utils/constants'; // Configuración de parámetros
import { rutaLibros } from './modules/book'; // Rutas relacionadas con los libros

const app = express();
const PUERTO = 3007; // Puerto en el que el servidor escuchará

// Configuración de middlewares
app.use(express.json()); // Middleware para parsear JSON en las solicitudes
app.use('/libro', rutaLibros); // Rutas para el manejo de libros

// Ruta principal
app.get('/', (req: Request, res: Response) => {
    res.status(200).send({ mensaje: '¡Hola, mundo!' }); // Respuesta de prueba
});

// Inicialización del servidor
app.listen(PUERTO, async () => {
    // Construcción de la URL de conexión a la base de datos
    const url = `mongodb://${Configuracion.HOST_BASE_DATOS}:${Configuracion.PUERTO_BASE_DATOS}/${Configuracion.NOMBRE_BASE_DATOS}`;
    
    try {
        // Conexión a la base de datos
        await inicializarBaseDatos(url);
        console.log(`Servidor en funcionamiento en el puerto ${PUERTO}`);
    } catch (error) {
        console.error('Error al conectar con la base de datos:', error);
        process.exit(1); // Salida del proceso con código de error
    }
});
