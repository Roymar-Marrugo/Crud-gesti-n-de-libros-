export interface Libro {
    titulo: string;
    autor: string;
    fechaPublicacion: Date;
    isbn: string;
    genero: string;
}
