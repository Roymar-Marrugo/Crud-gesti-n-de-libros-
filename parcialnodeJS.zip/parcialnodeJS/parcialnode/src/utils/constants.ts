import { config } from 'dotenv';

// Cargar las variables de entorno desde el archivo .env
config();

export class Configuracion {
    // Métodos estáticos permiten acceder a estos valores sin crear una instancia de la clase
    static readonly NOMBRE_BASE_DATOS = process.env.DATABASE_NAME || 'test';
    static readonly PUERTO_BASE_DATOS = process.env.DATABASE_PORT || 'test';
    static readonly HOST_BASE_DATOS = process.env.DATABASE_HOST || 'test';
}
